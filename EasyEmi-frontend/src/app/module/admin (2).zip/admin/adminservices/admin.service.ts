import { Injectable } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class AdminService {
   
  public isUserActive : Boolean = true;
  public isUserAddressDisabled : Boolean = true;
  public isUserBranchDisabled : Boolean = true;
  public isViewUserDisabled : Boolean = false;
  public isuserDocumentDisabled : Boolean = true;

  public adharCard : string;
  public isAdharDisplay : Boolean = false;
  public panCard : string;
  public isPanCardDisplay : Boolean = false;
  public passbook : string;
  public isPassbookDisplay : Boolean = false;
  public userPhoto : string;
  public isUserPhotoDisplay : Boolean = false;

  constructor(private formBuilder : FormBuilder, private http : HttpClient) { }

  public userDocument : FormGroup = this.formBuilder.group( {
    docId :null,
    adharCard : [''],
    panCard : [''],
    userPhoto : [''],
    passbook : ['']
  });

  public country : FormGroup = this.formBuilder.group({
    countryId : null,
    countryName : [''],
    countryCode : null,
    countryStatusCode : null
  });

  public state : FormGroup = this.formBuilder.group({
    stateId : null,
    stateName : [''],
    stateCode : null,
    stateStatusCode : null,
    country : this.country
  })

  public district : FormGroup = this.formBuilder.group({
    districtId : null,
	  districtName : [''],
    districtCode : null,
	  districtStatusCode : null,
	  state : this.state
  })

  public perm_country : FormGroup = this.formBuilder.group({
    countryId : null,
    countryName : [''],
    countryCode : null,
    countryStatusCode : null
  });

  public perm_state : FormGroup = this.formBuilder.group({
    stateId : null,
    stateName : [''],
    stateCode : null,
    stateStatusCode : null,
    country : this.perm_country
  })

  public perm_district : FormGroup = this.formBuilder.group({
    districtId : null,
	  districtName : [''],
    districtCode : null,
	  districtStatusCode : null,
	  state : this.perm_state
  })

  public userAddress : FormGroup = this.formBuilder.group({
    addressId : null,
    houseNo : ['',[Validators.required]],
    streetName : ['',[Validators.required]],
    area : ['',[Validators.required]],
    landmark : ['',[Validators.required]],
    taluka : ['',[Validators.required]],
    district : this.district,
    city : ['',[Validators.required]],
    // state : [''],
    // country : [''],
    pincode : ['',[Validators.required, Validators.pattern('[0-9]{6}')]],
    perm_houseNo : ['',[Validators.required]],
    perm_streetName : ['',[Validators.required]],
    perm_area : ['',[Validators.required]],
    perm_landmark : ['',[Validators.required]],
    perm_taluka : ['',[Validators.required]],
    perm_district : this.perm_district,
     perm_city : ['',[Validators.required]],
    // perm_state : [''],
    // perm_country : [''],
    perm_pincode : ['',[Validators.required, Validators.pattern('[0-9]{6}')]],
    statusCode : null,
  });

  public branchAddress : FormGroup = this.formBuilder.group({
    addressId : null,
    houseNo : [''],
    area : [''],
    streetName : [''],
    landMark : [''],
    city : [''],
    taluka : [''],
    district : [''],
    state : [''],
    country : [''],
    pincode : ['']
  })

  public branch : FormGroup = this.formBuilder.group({
    branchId : null,
    branchName : [''],
    branchType : [''],
    ifscCode : [''],
    micrCode : null,
    branchCode : null,
    branchContactNo : null,
    branchMailId : [''],
    status : null,
    branchAddress : this.branchAddress
  })

  public user : FormGroup = this.formBuilder.group({
    userId : null,
    firstName : ['', [Validators.required, Validators.minLength(3), Validators.pattern('[a-zA-Z ]*')]],
    middleName : ['', [Validators.required, Validators.minLength(3), Validators.pattern('[a-zA-Z ]*')]],
    lastName : ['', [Validators.required, Validators.minLength(3), Validators.pattern('[a-zA-Z ]*')]],
    mobileNo : ['', [Validators.required, Validators.pattern('[7-9][0-9]{9}')]],
    anotherMobileNo : ['', [Validators.required, Validators.pattern('[789][0-9]{9}')]],
    emailId : ['', [Validators.required, Validators.pattern('[a-zA-Z0-9][a-zA-Z0-9_.]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+')]],
    gender : [''],
    dateOfBirth : ['', [Validators.required, Validators.pattern('(0[1-9]|[1-2][0-9]|3[0-1])\/(0[1-9]|1[0-2])\/[0-9]{4}')]],
    dateOfJoining : ['', [Validators.required, Validators.pattern('(0[1-9]|[1-2][0-9]|3[0-1])\/(0[1-9]|1[0-2])\/[0-9]{4}')]],
    username : ['', [Validators.required, Validators.minLength(3)]],
    password : ['', [Validators.required, Validators.minLength(3)]],
    role : [''],
    userStatusCode : [''],
    userAddress : this.userAddress,
    userDocument : this.userDocument,
    userBranch : this.branch
  });

  url : string = "http://localhost:3000/user";
  
  registerUser(user) {
    this.user.reset();
    return this.http.post("http://localhost:8082/masteruser/register",user);
  }

  getUserAllData() {
    return this.http.get("http://localhost:8082/masteruser/getAllUser");
  }

  deleteUser(userId) {
    console.log(userId)
    return this.http.delete("http://localhost:8082/masteruser/deleteUser/"+userId);
  }

  updateUser(user) {
    this.user.reset();
    return this.http.put("http://localhost:8082/masteruser/updateuser",user);
  }

  getBranch() {
    return this.http.get("http://localhost:8082/masterbranch/getbranch");
  }

  getDistrict() {
    console.log("in address service")
    return this.http.get("http://localhost:8082/masterDistrict/fetch")
  }

  userDetails(id) {
    return this.http.get("http://localhost:8082/masteruser/getUserData/"+id);
  }

}
