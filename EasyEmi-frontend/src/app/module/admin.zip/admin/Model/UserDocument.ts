export class UserDocument{
    
	docId : number;
	adharCard : string;
	panCard : string;
	userPhoto : string;
}