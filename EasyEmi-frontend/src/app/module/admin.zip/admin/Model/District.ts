import { State } from './State';

export class District{
    districtId : number;
	districtName : string;
    districtCode : number;
	districtStatusCode : number;
	state : State;
}