import { UserAddress } from './UserAddress';
import { UserDocument } from './UserDocument';

export class User
{
    userId : number;
	firstName : string;
    middleName : string;
	lastName : string;
	mobileNo : number;
	anotherMobileNo : number;
	emailId : string;
	gender : string;
	dateOfBirth : string;
	dateOfJoining : string;
	username : string;
	password : string;
	role : string;
	userBranch : string;
	userStatusCode : string;
	userAddress : UserAddress;
	userDocument : UserDocument;
}