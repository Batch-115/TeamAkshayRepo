import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { Routes, RouterModule } from "@angular/router";
import { AdmindashboardComponent } from './admindashboard/admindashboard.component';
import { UserComponent } from './user/user.component';
import { ViewuserComponent } from './viewuser/viewuser.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { UseraddressComponent } from './useraddress/useraddress.component';
import { UserdocumentComponent } from './userdocument/userdocument.component';
import { HttpClientModule } from '@angular/common/http';
import { UserbranchComponent } from './userbranch/userbranch.component';

const adminrouting: Routes = [
  { path: "admindashboard", component: AdmindashboardComponent },
  { path: "user", component : UserComponent,
    children : [
      { path: 'useraddress', component: UseraddressComponent },
      { path: 'userdocument', component: UserdocumentComponent },
      { path: 'userbranch', component: UserbranchComponent }
    ] 
  },
  { path : "viewuser", component : ViewuserComponent }
];

@NgModule({
  declarations: [ AdmindashboardComponent,
    UserComponent,
    ViewuserComponent,
    UseraddressComponent,
    UserdocumentComponent,
    UserbranchComponent
  ],
  imports: [CommonModule,
  RouterModule.forChild(adminrouting),
  ReactiveFormsModule,
  HttpClientModule,
  FormsModule
]
})
export class AdminModule {}
