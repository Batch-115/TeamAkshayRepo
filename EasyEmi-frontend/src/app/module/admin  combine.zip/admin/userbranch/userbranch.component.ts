import { Component, OnInit } from '@angular/core';
import { AdminService } from '../adminservices/admin.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Branch } from '../Model/Branch';

@Component({
  selector: 'app-userbranch',
  templateUrl: './userbranch.component.html',
  styleUrls: ['./userbranch.component.scss']
})
export class UserbranchComponent implements OnInit {
  headElements = ['', 'Branch Id', 'Branch Name', 'Branch MailId', 'Branch Type', 'Branch AddressId', 'Branch City'];
  branches : Branch[];
  constructor(
     private adminSer : AdminService,
     private router : Router, 
     private route : ActivatedRoute) { }

  ngOnInit() {
    this.adminSer.isUserActive = false;
    this.adminSer.isUserBranchDisabled = false;
    this.adminSer.isuserDocumentDisabled=true;
    this.adminSer.getBranch().subscribe((data : Branch[]) => this.branches=data )
  }

  onUserBranchSubmit(branch){
    console.log(branch)
    this.adminSer.branch.setValue(branch);
    this.router.navigate(['../userdocument'], { relativeTo: this.route })
    console.log(this.adminSer.district.value);
  }

}
