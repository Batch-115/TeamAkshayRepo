export class Neft {

    neft_Id:number;
	base_Branch_Name:string;
	account_No:number;
	 name_Of_Account_Holder:string;
	beneficiary_Bank_Name:string;
	ifsc_Code:string;
	beneficiary_Account_No:number;
	beneficiary_Name:string;
	amount:number;

}
