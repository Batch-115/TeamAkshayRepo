export class Phonepay {
    phonepay_Id:number;
   upi_Id:number;
   mobileNo:number;
   amount:number;
}
