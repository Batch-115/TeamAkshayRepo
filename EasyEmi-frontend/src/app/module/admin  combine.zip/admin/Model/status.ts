export class Status {
    statusId:number;
	statusDescription:string;
	statusCode:number;

}
