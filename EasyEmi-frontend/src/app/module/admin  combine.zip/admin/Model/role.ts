export class Role {
roleId:number;
roleName:string;
 roleCode:number;
roleStatusCode:number;


}
