export class Card {

     card_Id:number;
	 card_Type:string;
	pcardNo:number;
	name:string;
	card_Validuptil_Month:number;
	card_Validuptil_Year:number;
	 cvc:number;
	 amount:number;


}
