export class Country{
    countryId : number;
	countryName : string;
	countryCode : number;
	countryStatusCode : number;
}